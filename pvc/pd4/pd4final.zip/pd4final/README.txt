/********************
*
*	Para compilar os arquivos do código fonte, é utilizado CMakeLists.txt. 
*
*	Execute as seguintes ações no terminal para compilar e executar corretamente:
*
*	1- cmake .  
*	2- make
*	3- /main 46.gif 46gt.gif
*
*	Obs: Para o algoritmo funcionar corretamente, insira primeiro a imagem e depois seu Ground Truth, indicado por "gt"
*
*********************/

