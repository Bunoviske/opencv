/********************
*
*	Para compilar os arquivos do código fonte, é utilizado CMakeLists.txt. 
*
*	Execute as seguintes ações no terminal para compilar e executar corretamente:
*
*	1- cmake .  
*	2- make
*	3- /main video.avi
*
*	
*	
*********************/
