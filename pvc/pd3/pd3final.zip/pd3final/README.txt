/********************
*
*	Para compilar os arquivos do código fonte, é utilizado CMakeLists.txt. 
*
*	Execute as seguintes ações no terminal para compilar e executar corretamente:
*
*	1- cmake .  
*	2- make
*	3- ./main imgL.jpg imgR.jpg
*
*	Obs: Para o algoritmo funcionar corretamente, insira primeiro a imagem esquerda e indique isso com a letra 'L' após o nome dela. 
*    	 O mesmo serve para a imagem direita com a letra 'R'.
*
*********************/

