/********************
*
*	Para compilar os arquivos do código fonte, é utilizado CMakeLists.txt. 
*
*	Execute as seguintes ações no terminal para compilar e executar corretamente:
*
*	1- cmake .  
*	2- make
*	3- /main 
*
*	Obs.: Lembre-se que para definir o template você deve selecioná-lo a partir de dois cliques na janela de vídeo.
*	
*********************/
