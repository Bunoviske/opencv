char* itoa(int value, char* result, int base);
