#include "processing.h"
#include "itoa.h"


void mainCalib(int);
void mediaSTD(CvMat *media, CvMat *desvio, CvMat **matrix);
