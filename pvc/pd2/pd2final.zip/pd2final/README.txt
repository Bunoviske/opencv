/********************
*
*	Para compilar os arquivos do código fonte, é utilizado CMakeLists.txt. 
*
*	Execute as seguintes ações no terminal para compilar e executar corretamente:
*
*	1- cmake .  
*	2- make
*	3- ./main CALIB ou ./main LOAD
*
*	Obs: Use CALIB para calibrar ou LOAD para carregar um arquivo xml previamente obtido com os nomes: "IntrinsicsFinal.xml" e
*   "DistortionFinal.xml" (os arquivos devem estar no mesmo diretório). As duas opções de argumento executam a régua visual criada.
*
*********************/

